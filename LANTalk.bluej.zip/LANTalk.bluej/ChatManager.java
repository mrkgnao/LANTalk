/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class ChatManager {

    int uid;
    String name;
    PipedInputStream inPipe;
    PrintStream outStream;

    public ChatManager(PrintStream outStream, int uid, String name) {
        this.outStream = outStream;
        this.uid = uid;
        this.name = name;
    }

    void mainLoop() throws IOException {
        Config conf = Config.DEFAULT_CONFIG;
        IOHandler ioh = new IOHandler(conf, outStream);
        conf.setJoined(uid);
        conf.setUserName(uid, name);
        ioh.changeNick(uid, name);
        outStream.println(name + " has joined the chat");

        ioh.createFiles();

        String userInput = "", oldName = "", newName = "";
        File bft, ift, cft;
        String bpath, ipath, cpath;
        long bmod, imod, cmod;
        boolean online;
        
        String lastMsg = "";

        long[] broadcastModT = new long[conf.maxUsers];
        long[] infoModT = new long[conf.maxUsers];
        long consoleModT = new File(conf.consolePath(uid)).lastModified();

        boolean[] onlineMod = new boolean[conf.maxUsers];

        for (int i = 0; i < conf.maxUsers; ++i) {
            bft = new File(conf.broadcastPath(i));
            ift = new File(conf.infoPath(i));
            broadcastModT[i] = bft.lastModified();
            infoModT[i] = ift.lastModified();
            onlineMod[i] = conf.hasJoined[i];
        }

        do {

            cft = new File(conf.consolePath(uid));
            cmod = cft.lastModified();
            // print new messages
            for (int i = 0; i < conf.maxUsers; ++i) {
                bpath = conf.broadcastPath(i);
                bft = new File(bpath);
                bmod = bft.lastModified();

                ipath = conf.infoPath(i);
                ift = new File(ipath);
                imod = ift.lastModified();

                online = conf.hasJoined[i];

                if (bmod != broadcastModT[i]) {
                    outStream.println(
                        conf.getUserName(i) + ": "
                        + fileContents(bpath));

                    broadcastModT[i] = bmod;
                }

                if (imod != infoModT[i]) {
                    if (fileContents(ipath).equals("LEFT")) {
                        outStream.println(
                            conf.getUserName(i)
                            + " has left the chat");
                    } else {
                        oldName = conf.getUserName(i);
                        newName = fileContents(ipath);
                        if (oldName == null && newName != null) {
                            outStream.println(newName + " has joined the chat.");
                        } else if (!oldName.equals(newName)) {
                            outStream.println(oldName
                                + " changed their name to "
                                + newName);
                        }
                        conf.setUserName(i, newName);
                    }
                    infoModT[i] = imod;
                }
            }

            // this is so roundabout
            if (cmod != consoleModT) {
                userInput = fileContents(conf.consolePath(uid));
                if (userInput != null && userInput.length() > 0) {
                    if (userInput.charAt(0) != '\\' && userInput.trim() != lastMsg.trim()) {
                        ioh.broadcast(uid, userInput);
                        System.out.println("Printed " + userInput + " l: " + userInput.length());
                        lastMsg = userInput;
                    } else if (userInput.charAt(0) == '\\') {
                        String command = userInput.split(" ")[0];
                        switch (command) {
                            case "\\nick":
                            String rest = userInput.substring(userInput.indexOf(' ') + 1);
                            ioh.changeNick(uid, rest);
                            break;
                            case "\\bye":
                            conf.setLeft(uid);
                            ioh.sendLeave(uid);
                            System.exit(0);
                            break;
                            case "\\online":
                            String toPrint = "";
                            for (int i = 0; i < conf.maxUsers; ++i) {
                                toPrint = "Users online: ";
                                if (conf.hasJoined[i]) {
                                    toPrint += conf.getUserName(i);
                                }
                            }
                            outStream.println(toPrint);
                            break;
                            default:
                            outStream.println("Unknown command.");
                            break;
                        }
                    }
                }
                consoleModT = cmod;
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ie) {
                }
            }
        } while (!userInput.equals("\\bye"));
    }

    // get computer name
    // in the lab this will be HSLABmn, for 0 <= m, n <= 9
    static String getComputerName() {
        Map<String, String> env = System.getenv();
        if (env.containsKey("COMPUTERNAME")) {
            return env.get("COMPUTERNAME");
        } else if (env.containsKey("HOSTNAME")) {
            return env.get("HOSTNAME");
        } else {
            return "Unknown Computer";
        }
    }

    // only the first line. this is by design.
    static String fileContents(String path) {
        String ret = "";
        try {
            ret = new BufferedReader(new FileReader(path)).readLine();
        } catch (IOException ioe) {}
        return (ret == null ? "" : ret);
    }
}
