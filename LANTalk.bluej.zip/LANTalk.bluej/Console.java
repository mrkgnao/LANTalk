/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.EventQueue;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingWorker;

/**
 *
 * @author admin
 */
public class Console extends JFrame implements KeyListener {

    private JTextField prompt;
    private JTextArea log;
    private JScrollPane sp;

    private final PipedInputStream inPipe = new PipedInputStream();
    private final PipedInputStream outPipe = new PipedInputStream();

    private IOHandler ioh;

    private int uid;

    public Console(String title, int uid, String name) throws IOException {
        super(title);

        this.uid = uid;
        System.setIn(inPipe);
        PrintStream outStream = new PrintStream(new PipedOutputStream(outPipe), true);

        this.ioh = new IOHandler(Config.DEFAULT_CONFIG, outStream);

        JPanel p = new JPanel();
        p.setLayout(null);
        
        log = new JTextArea();
        log.setEditable(false);
        log.setBounds(10, 10, 1000, 510);
        p.add(log);
        
        prompt = new JTextField();
        prompt.setBounds(10, 530, 1000, 80);
        prompt.addKeyListener(this);
        p.add(prompt);

        getContentPane().add(p);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        setSize(1030, 650);
        setLocationRelativeTo(null);

        (new SwingWorker<Void, String>() {
            protected Void doInBackground() throws Exception {
                Scanner s = new Scanner(outPipe);
                while (s.hasNextLine()) {
                    String line = s.nextLine();
                    publish(line);
                }
                return null;
            }

            @Override
            protected void process(java.util.List<String> chunks) {
                for (String line : chunks) {
                    if (line.length() < 1) {
                        continue;
                    }
                    log.append(line.trim() + "\n");
                }
            }
        }).execute();

        new ChatManager(outStream, uid, name).mainLoop();
    }

    public void execute() {
        String text = prompt.getText();
        prompt.setText("");
        ioh.fprint(text, ioh.config.consolePath(uid));
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            execute();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            execute();
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
            execute();
        }
    }
}
