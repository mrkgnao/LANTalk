/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Scanner;

/**
 *
 * @author admin
 */
public class IOHandler {

    Config config;
    PrintStream outS;

    public IOHandler(Config config, PrintStream outS) {
        this.config = config;
        this.outS = outS;
    }

    // set up I/O stuff
    BufferedReader in = null;
    PrintWriter out = null;
    Scanner userInput = new Scanner(System.in);

    /**
     * Sets up the files in the remote directory.
     */
    void createFiles() throws IOException {
        for (int i = 0; i < config.maxUsers; ++i) {
            (new File(config.broadcastPath(i))).createNewFile();
            (new File(config.msgPath(i))).createNewFile();
            (new File(config.infoPath(i))).createNewFile();
            // System.out.println("Created files for user #" + i);
        }
    }

    void broadcast(int uid, String msg) {
        fprint(msg, config.broadcastPath(uid));
    }

    void pm(int fromId, int toId, String msg) {
        fprint(config.getUserName(fromId) + "\n" + msg, config.msgPath(toId));
    }

    void changeNick(int uid, String newName) {
        fprint(newName, config.infoPath(uid));    
    }
    
    void sendLeave(int uid) {
       fprint("LEFT", config.infoPath(uid));  
    }
    
    void printLeaveMsg(int uid) {
        outS.println(config.getUserName(uid) + " has left the chat");
    }
    
    void fprint(String s, String filename) {
        // TODO: 
        // this is probably too slow!
        // make an array of PrintWriters, one for each person?
        try {
            out = new PrintWriter(filename, "UTF-8");
            out.print(s);
        } catch (FileNotFoundException | UnsupportedEncodingException e) {
        } finally {
            out.close();
        }
    }
}
