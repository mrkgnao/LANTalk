/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author admin
 */
public class Config {

    final String remoteDir;

    final String configDir;
    final String infoDir;
    final String broadcastDir;
    final String msgsDir;
    final String consoleDir;

    final int maxUsers;

    String[] userNames;
    boolean[] hasJoined;

    public Config(String rDir, int numUsers) {
        this.remoteDir = rDir;
        this.msgsDir = remoteDir + "\\msgs";
        this.broadcastDir = remoteDir + "\\broadcasts";
        this.infoDir = remoteDir + "\\info";
        this.configDir = remoteDir + "\\config";
        this.consoleDir = remoteDir + "\\console";

        this.maxUsers = numUsers;

        this.userNames = new String[maxUsers];
        this.hasJoined = new boolean[maxUsers];
    }

    static Config DEFAULT_CONFIG
            = new Config("C:\\Users\\admin\\Dropbox\\remote", 10);
    
    void addUser(int id, String name) throws Exception {
        if(id > maxUsers) throw new Exception("Invalid id");
        this.userNames[id] = name;
    }

    String msgPath(int id) {
        return msgsDir + "\\" + id;
    }

    String broadcastPath(int id) {
        return broadcastDir + "\\" + id;
    }
    
    String consolePath(int id) {
        return consoleDir + "\\" + id;
    }

    String infoPath(int id) {
        return infoDir + "\\" + id;
    }
    
    public String getUserName(int id) {
        return userNames[id];
    }

    public void setUserName(int id, String newName) {
        this.userNames[id] = newName;
    }
    
    public void setJoined(int id) {
        this.hasJoined[id] = true;
    }
    
    public void setLeft(int id) {
        this.hasJoined[id] = false;
    }
}
